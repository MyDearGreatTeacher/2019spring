#/bin/bash
docker rmi ch5
