Chapter 2 to Chapter 8 contains code.
Chapter 1 do not have code.