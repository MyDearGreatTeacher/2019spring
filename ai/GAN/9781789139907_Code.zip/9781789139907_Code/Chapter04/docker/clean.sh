#/bin/bash
docker rmi ch4
