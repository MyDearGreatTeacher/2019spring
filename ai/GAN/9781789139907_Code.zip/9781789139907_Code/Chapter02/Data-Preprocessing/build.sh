#/bin/bash
nvidia-docker build -t ch2 . 
