#/bin/bash
docker rmi ch7
