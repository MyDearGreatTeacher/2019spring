#/bin/bash
docker rmi ch6
