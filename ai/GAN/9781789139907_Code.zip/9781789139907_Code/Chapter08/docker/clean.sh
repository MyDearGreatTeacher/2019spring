#/bin/bash
docker rmi ch8
